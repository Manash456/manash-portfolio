HOW TO ADD YOUR PHOTOS & VIDEOS
================================

1. Put your files into the "photos" and "videos" folders, using these EXACT names:

   photos/hero.jpg      -> your best portrait (top of page)
   photos/photo-01.jpg  -> Portrait Retouch card
   photos/photo-02.jpg  -> Creative Manipulation card
   photos/photo-03.jpg  -> AI Creative Edit card
   photos/photo-04.jpg  -> Before/After card

   videos/reel-01.mp4   -> Reel 1
   videos/reel-02.mp4   -> Reel 2
   videos/reel-03.mp4   -> Reel 3

2. If your file is a .png or .jpeg instead of .jpg, either rename it to
   match, or open index.html in a text editor and change the file
   extension in the matching src="photos/....jpg" line.

3. Open index.html in any browser (double click it) to preview.
   Any slot without a matching file just shows the text placeholder,
   so nothing breaks.

4. To publish it online for free, drag this whole folder into
   netlify.com/drop, or upload it to GitHub Pages.

TIP: Send Claude your photos/videos directly in chat and say which
slot each one goes in (e.g. "this is hero.jpg") and it will build
the final zip for you.
